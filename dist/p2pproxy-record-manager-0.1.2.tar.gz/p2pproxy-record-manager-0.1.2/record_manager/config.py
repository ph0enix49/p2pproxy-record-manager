# -*- coding: utf-8 -*-
# available languages
LANGUAGES = {
    'en': 'English',
    'ru': 'Русский'
}